library(plotly)
library(shiny)

# compute a correlation matrix
#source('lambda.R')
#-------------Code to compute lambda
library(ggplot2)
library(maptools)
library(dplyr)
library(data.table)
library(plotly)

data <- read.csv('crimes2016forprediction.csv', stringsAsFactors = FALSE)


lambda <- function(data, location, t, dx = 0.001, dy = 0.001, dt = 100){
  # Number of crimes in this time range
  subset = data[((data$Hour < (t+dt))&(data$Hour > t)),]
  
  # In this spatial cell
  nbcrimes = nrow(subset[((subset$X < (location[1]+dx))&(subset$X > (location[1]-dx))&(subset$Y > (location[2]-dy))&(subset$Y < (location[2]+dy))),])
  
  # Average per day per minuts
  avg = nbcrimes/(366*60)
  avg
}

x = matrix(nrow=9, ncol=9)
y = matrix(nrow=9, ncol=9)

x0 = -122.4222 + 0.001
y0 = 37.79078 - 0.001
step = 0.002

for (i in 1:9){
  for (j in 1:9){
    x[i,j] = x0 + step *(j-1)
    y[i,j] = y0 - step * (i-1)
  }
}

lambda_mat = array(c(0), c(24,9,9))
lambda_mat2 = array(c(0), c(24,9,9))

for (t in 1:24){
  for (i in 1:9){
    for (j in 1:9){
      location = c(x[i,j],y[i,j])
      time = (t-1)*100
      res = lambda(data, location, time)
      lambda_mat[t,i,j] <- res
      lambda_mat2[t,9-i+1,j] <- res
      
    }
  }
}

typefun <- function(data, location, t, dx = 0.001, dy = 0.001, dt = 100){
  # Number of crimes in this time range
  subset = data[((data$Hour < (t+dt))&(data$Hour > t)),]
  
  # In this spatial cell
  typesub = subset[((subset$X < (location[1]+dx))&(subset$X > (location[1]-dx))&(subset$Y > (location[2]-dy))&(subset$Y < (location[2]+dy))),]
  
  if (length(typesub)>0){
    return(names(sort(table(typesub$Category),decreasing=TRUE)[1:3]))
  }
  else{
    return(rep("No records",3))
  }
}


type = array(c(""),c(24,9,9))
type2 = array(c(""),c(24,9,9))
for (t in 1:24){
  for (i in 1:9){
    for (j in 1:9){
      type[t,9-i+1,j] <- paste("",typefun(data, c(x[i,j],y[i,j]),(t-1)*100)[1])
      type2[t,9-i+1,j] <- paste("",typefun(data, c(x[i,j],y[i,j]),(t-1)*100)[2])
      
    }
  }
}



correlation <- round(cor(mtcars), 3)
nms <- names(mtcars)


ui <- fluidPage(
  titlePanel("San Francisco - Risk level - Spatio-temporal Evolution"),
  sidebarPanel(
    sliderInput("time",
                "Hour :",
                min = 0,max = 23,value = 12,step = 1, width = 10000),
    verbatimTextOutput("texttime"),
    verbatimTextOutput("textlocation"),
    verbatimTextOutput("textposition"),
    verbatimTextOutput("typetxt"),
    img(src = "mapcells.png", height = 400, width = 350)),
  mainPanel(
    plotlyOutput("heat2"),
    plotlyOutput("scatterplot")


  ),

  verbatimTextOutput("selection")
)

server <- function(input, output, session) {
  t <- reactive(input$time)
  
  output$heat2 <- renderPlotly({
    plot_ly(x = 1:9, y = 1:9, z = 60*lambda_mat2[t()+1,,],  type = "heatmap", source = "heatplot",
      colorscale = "Greys",
      zauto = F,
      zmin = 0,
      zmax = 0.18, colorbar = list(title = "Lambda*60"))%>%
      layout(title = "Lambda - Spatial distribution at selected hour")
  })
  
  output$texttime <- renderText({ 
    paste("Time range :", t(),"to", t()+1)
  })
  
  output$textlocation <- renderText({
    loc2 = which(lambda_mat2[t()+1,,] == max(lambda_mat2[t()+1,,]), arr.ind = TRUE)
    paste("Highest crime rate in cell", loc2[1,2],"-",loc2[1,1])
  })
  
  output$textposition <- renderText({
    loc = which(lambda_mat[t()+1,,] == max(lambda_mat[t()+1,,]), arr.ind = TRUE)
    paste("GPS position : ",  "\n",x[loc],";",y[loc])
  })
  
  
  ## OTHER
  output$selection <- renderPrint({
    s <- event_data("plotly_click")
    if (length(s) == 0) {
      "Click on a cell in the heatmap to display a scatterplot"
    } else {
      cat("You selected: \n\n")
      as.list(s)
    }
  })
  
  output$scatterplot <- renderPlotly({
    s <- event_data("plotly_click", source = "heatplot")
    if (length(s)) {
      vars <- c(s[["x"]], s[["y"]])
      
      d <- data.frame("hour" = 1:24)
      d$X1 <- lambda_mat2[,s[["x"]],s[["y"]]]*60
      
      plot_ly(d, x = ~hour) %>%
        add_markers(y = ~X1) %>%
        #add_lines(y = ~yhat) %>%
        layout(title = "Lambda - Daily evolution in the selected cell",
               xaxis = list(title = paste("X = ", s[["x"]])), 
               yaxis = list(title = paste("Y = ", s[["y"]])), 
               showlegend = FALSE)
      
      
    } else {
      plotly_empty()
    }
  })
  
  output$typetxt <- renderText({
    s <- event_data("plotly_click", source = "heatplot")
    if (length(s)) {
      vars <- c(s[["x"]], s[["y"]])
      paste("Most Common Type :", "\n",type[t()+1,s[["x"]],s[["y"]]], "\n", type2[t()+1,s[["x"]],s[["y"]]])
      
    }
  })
  
}

shinyApp(ui, server)

